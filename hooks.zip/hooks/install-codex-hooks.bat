@echo off
setlocal EnableExtensions

set "SOURCE_DIR=%~dp0"
set "CODEX_DIR=%USERPROFILE%\.codex"
set "HOOKS_DIR=%CODEX_DIR%\hooks"
set "TARGET_JSON=%CODEX_DIR%\hooks.json"
set "TARGET_PS1=%HOOKS_DIR%\agents-init.ps1"

if not defined USERPROFILE (
    echo [ERROR] USERPROFILE is not defined.
    exit /b 1
)

if not exist "%SOURCE_DIR%hooks.json" (
    echo [ERROR] Missing file: "%SOURCE_DIR%hooks.json"
    exit /b 1
)

if not exist "%SOURCE_DIR%agents-init.ps1" (
    echo [ERROR] Missing file: "%SOURCE_DIR%agents-init.ps1"
    exit /b 1
)

if not exist "%CODEX_DIR%" mkdir "%CODEX_DIR%"
if errorlevel 1 (
    echo [ERROR] Could not create "%CODEX_DIR%".
    exit /b 1
)

if not exist "%HOOKS_DIR%" mkdir "%HOOKS_DIR%"
if errorlevel 1 (
    echo [ERROR] Could not create "%HOOKS_DIR%".
    exit /b 1
)

if exist "%TARGET_JSON%" (
    copy /Y "%TARGET_JSON%" "%TARGET_JSON%.bak" >nul
    if errorlevel 1 (
        echo [ERROR] Could not back up "%TARGET_JSON%".
        exit /b 1
    )
)

if exist "%TARGET_PS1%" (
    copy /Y "%TARGET_PS1%" "%TARGET_PS1%.bak" >nul
    if errorlevel 1 (
        echo [ERROR] Could not back up "%TARGET_PS1%".
        exit /b 1
    )
)

copy /Y "%SOURCE_DIR%hooks.json" "%TARGET_JSON%" >nul
if errorlevel 1 (
    echo [ERROR] Could not copy hooks.json.
    exit /b 1
)

copy /Y "%SOURCE_DIR%agents-init.ps1" "%TARGET_PS1%" >nul
if errorlevel 1 (
    echo [ERROR] Could not copy agents-init.ps1.
    exit /b 1
)

echo [OK] Installed:
echo      "%TARGET_JSON%"
echo      "%TARGET_PS1%"
echo.
echo Existing target files, if any, were saved as .bak before replacement.

endlocal
exit /b 0
