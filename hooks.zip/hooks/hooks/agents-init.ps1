# SessionStart initializer for Main Agent.
# - Always injects a small Core-First governance rule for the main coding agent.
# - Always injects conservative autonomous Git maintenance rules.
# - Advertises MiniMax as an optional external coding subagent without forcing routing.
# - Adds repository-specific AGENTS.md bootstrap guidance only when needed.
# Keep the persistent context intentionally small; skills/tools own detailed methodology.

$coreFirstInstruction = @'
The installed Core-First Governance plugin is the canonical governance layer for
software work in this session.

Immediately load and follow $core-first-orchestration before deciding whether the
current task can use the Local Short Path or requires deeper governance. Do not
independently decide whether Core-First itself is needed.

Let that canonical orchestration skill decide when the sibling
$core-first-extension-architecture, $core-first-verifier, or $independent-review
skills are required. Do not recreate their detailed rules from memory or duplicate
them in project instructions.

The user-facing Main agent remains the final integrator and must perform its own
investigation and verification; delegation never transfers that responsibility.
'@

$gitInstruction = @'
Maintain Git autonomously as the local recovery and change-history mechanism.

At the start of repository work, identify the real project/repository root and inspect
Git status plus relevant existing diffs before editing. If the project is not already
inside a Git repository, initialize one at the project root before substantial changes.

Preserve pre-existing and user-authored changes. Stage and commit only changes that
belong to the current agent work. After a coherent, verified milestone, create a local
checkpoint commit with a concise descriptive message when doing so improves
recoverability and history; do not create noisy commits for trivial intermediate steps.

Before committing, inspect the staged diff and run the narrowest relevant verification.
Never push, force-push, reset, clean, rebase, amend, discard, overwrite, or otherwise
rewrite/remove existing work unless the user explicitly requests that operation.
Do not commit secrets, credentials, generated caches, build output, or unrelated files.
'@

$contextParts = [System.Collections.Generic.List[string]]::new()
$contextParts.Add($coreFirstInstruction.Trim())
$contextParts.Add($gitInstruction.Trim())

$miniMaxInstruction = @'
MiniMax M3 is available through multi_mcp_provider as an optional external coding
subagent alongside native subagents. Treat it as a delegated-agent capability,
not as mandatory or globally preferred. Task fit, reviewer independence, cost, and
context capacity may inform routing.

Use minimax_analyze for bounded analysis/investigation, minimax_create_patch for
proposal-only implementation, minimax_review_patch for fresh external patch review,
and minimax_continue_task to continue the returned session. minimax_compress_context
may create a compact handoff when useful. For unusually large evidence sets,
mode=deep targets MiniMax M3's 1M model context window with a server-side safety
reserve.

Follow the Core-First orchestration context envelope: give minimum sufficient task
context, explicit authority/scope, constraints, acceptance criteria, and expected
evidence. If MiniMax returns needs_context, continue the same session with only the
specific missing evidence.

For independent review, do not preload the main agent's rationale, conclusions, or
Core-First methodology unless they are themselves part of the applicable project
requirements. Main Agent remains the final decision owner, editor, verifier, and committer.
'@

$contextParts.Add($miniMaxInstruction.Trim())

# Read the SessionStart payload supplied by Main Agent.
$inputJson = [Console]::In.ReadToEnd()

try {
    $payload = $inputJson | ConvertFrom-Json
} catch {
    # Core-First does not depend on repository discovery.
    $payload = $null
}

if ($null -ne $payload) {
    $workingDirectory = $payload.cwd

    if ($workingDirectory -and (Test-Path -LiteralPath $workingDirectory)) {
        # Find the repository root without changing the current directory.
        $repositoryRoot = & git -C $workingDirectory rev-parse --show-toplevel 2>$null

        if ($LASTEXITCODE -eq 0 -and $repositoryRoot) {
            $repositoryRoot = $repositoryRoot.Trim()
            $agentsPath = Join-Path $repositoryRoot "AGENTS.md"

            if (-not (Test-Path -LiteralPath $agentsPath)) {
                $agentsInstruction = @'
This repository does not yet contain a root AGENTS.md.

Before making substantial repository changes, inspect the repository and draft
a concise AGENTS.md for future coding agents.

Derive instructions only from verified repository evidence, including:
- existing documentation;
- package and build configuration;
- CI workflows;
- test and lint configuration;
- established code patterns.

Include only durable project-specific guidance:
- important directories and entry points;
- verified build, test, lint, and run commands;
- architectural boundaries and conventions;
- important constraints and definitions of done.

Do not copy the global working style into AGENTS.md.
Do not invent commands, conventions, or requirements.
Keep the file concise and link to existing documentation instead of duplicating it.
Show the proposed contents or diff for review before finalizing it.

If the user's current request is urgent or unrelated, do not block it merely to
create AGENTS.md; mention the missing file and handle it at an appropriate point.
'@
                $contextParts.Add($agentsInstruction.Trim())
            }
        }
    }
}

$combinedContext = $contextParts -join "`n`n"

$result = @{
    hookSpecificOutput = @{
        hookEventName     = "SessionStart"
        additionalContext = $combinedContext
    }
}

$result | ConvertTo-Json -Depth 5 -Compress
exit 0
